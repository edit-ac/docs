# Recipe source overlay

Overlay these repository-relative files in the qualified local docs checkout. Exact unpublished tarballs, pinned Node/npm and installed Playwright are prerequisites, not included SDK releases. Shared-profile.json points at the immutable architecture evidence with complete emitted site assets. README.md in examples/recipes describes commands. No registry, cloud, native, OS or budget qualification.
